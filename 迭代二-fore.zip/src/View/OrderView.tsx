import React, { useEffect, useState } from "react";
import "../css/Home.css";
import { Input } from "antd";
import { OrderTable } from "../components/book/OrderTable";
import { Cookies } from "react-cookie";
import { getOrder } from "../Service/OrderService";
import { IOrder, IOrderItem } from "../interface";

const { Search } = Input;

export const OrderView = () => {
  const onSearch = (value: string) => {
    const newDate = data.map((order: IOrder) => ({
      ...order,
      orderItems: order.orderItems.filter((item: IOrderItem) =>
        item.book.name.toLowerCase().includes(value.toLowerCase())
      ),
    }));

    newDate.forEach((order: IOrder) => {
      if (order.orderItems.length === 0) {
        const index = newDate.indexOf(order);
        newDate.splice(index, 1);
      }
    });
    // console.log(newDate);
    setFilterData(newDate);
  };

  const cookie = new Cookies();
  const user = cookie.get("currentUser");
  const [data, setData] = useState<IOrder[]>([]);
  const [filterData, setFilterData] = useState<IOrder[]>([]);

  useEffect(() => {
    getOrder(user.id).then((res: IOrder[]) => {
      setData(res);
      setFilterData(res);
    });
  }, []);

  return (
    <div className="allView">
      <h1>My Order</h1>
      <Search
        placeholder="input search text"
        onChange={(event) => onSearch(event.target.value)}
        enterButton
      />

      <div style={{ marginRight: "30px", marginTop: "5px" }}>
        {filterData.map((item: IOrder) => (
          <OrderTable
            order={item}
            data={filterData}
            setData={(newData: IOrder[]) => setFilterData(newData)}
          />
        ))}
      </div>
    </div>
  );
};
