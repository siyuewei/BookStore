import React, { useEffect, useState } from "react";
import { Input } from "antd";
import { BookList } from "../components/book/BookList";
import { BookCarousel } from "../components/book/Carousel";
import "../css/Book.css";
import { getBooks } from "../Service/BookService";
import { IBook } from "../interface";
import { bookData } from "../data";

const { Search } = Input;

export const BooksView = () => {
  // const [searchValue, setSearchValue] = useState("");
  //
  // const handleChange = (value: string) => {
  //   setSearchValue(value);
  // };
  const [data, setData] = useState<IBook[]>(bookData);
  const [filterData, setFilterData] = useState<IBook[]>(bookData);

  useEffect(() => {
    getBooks().then((res: IBook[]) => {
      setData(res);
      setFilterData(res);
      console.log(res);
    });
  }, []);

  const handleSearch = (value: string) => {
    setFilterData(
      data.filter((item) =>
        item.name.toLowerCase().includes(value.toLowerCase())
      )
    );
  };

  return (
    <div className="allView">
      <Search
        placeholder="input search text"
        onChange={(value) => {
          handleSearch(value.target.value);
        }}
        enterButton
      />
      <BookCarousel />
      <BookList filterData={filterData} />
    </div>
  );
};
