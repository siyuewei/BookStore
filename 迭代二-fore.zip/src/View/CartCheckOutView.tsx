export const CartCheckOutView = () => {
  return (
    <>
      <div
        style={{
          height: "200px",
          textAlign: "center",
          justifyContent: "center",
          alignItems: "center",
          display: "flex",
        }}
      >
        <div>
          <h1>订单提交成功</h1>
          <h4>enjoy reading ^.^</h4>
        </div>
      </div>
    </>
  );
};
