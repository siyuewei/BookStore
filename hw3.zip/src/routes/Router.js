import {BrowserRouter, Route, Routes, Outlet, Navigate} from "react-router-dom";
import React from "react";
import HomeView from "../View/HomeView";
import {BooksView} from "../View/BooksView";
import {CartView} from "../View/CartView";
import {ProfileView} from "../View/ProfileView";
// import {Excel} from "../View/ExcelView";
export const Router = () => {
    return <BrowserRouter>
        <Routes>
            <Route path="/" element={<HomeView />}>
                <Route path="books" element={<BooksView/>}></Route>
                <Route path="cart" element={<CartView />} />
                <Route path="profile" element={<ProfileView/>}></Route>
                <Route path="/" element={<Navigate to="books" />} />
            </Route>


        </Routes>
    </BrowserRouter>
}