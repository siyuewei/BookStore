import React from "react";

export const ProfileView = () => {
    return(
        <div>profile</div>
    );
}