import React from "react";

export const BooksView = () => {
    return (
        <div>books</div>
    );
}
