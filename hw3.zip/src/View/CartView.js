import React from "react";

export const CartView = () => {
    return (
        <div>cart</div>
    );
}
