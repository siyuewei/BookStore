import PropTypes from "prop-types";
import React from "react";
import {Toolbar} from "../components/layout/Toolbar";
import {Table} from "../components/layout/Table";
export class Excel extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            data: this.props.initialData,
            sortby: null,
            descending: false,
            edit: null, // [row index, cell index],
            search: false,
            preSearchData: null,
        };
    }

    render = () => {
        return (
            <div>
                <Toolbar
                    state={this.state}
                    setState={(state)=>this.setState(state)}
                />
                <Table
                    state={this.state}
                    setState={(state)=>this.setState(state)}
                    headers={this.props.headers}
                />
            </div>
        );
    };

};

Excel.propTypes = {
    headers: PropTypes.arrayOf(
        PropTypes.string
    ),
    initialData: PropTypes.arrayOf(
        PropTypes.arrayOf(
            PropTypes.string
        )
    ),
};
