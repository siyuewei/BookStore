import { Button, Descriptions, Image, Input } from "antd";
import { addBook, getBookByBookId, updateBook } from "../Service/BookService";
import React, { useState } from "react";
import { IBook } from "../interface";

export function AddBookView() {
  const [info, setInfo] = useState<IBook>({
    id: 0,
    name: "",
    isbn: "",
    author: "",
    price: 0,
    inventory: 0,
    description: "",
    image: "三体.jpg",
  });
  const [tmpInfo, setTmpInfo] = useState<IBook>({
    id: 0,
    name: "",
    isbn: "",
    author: "",
    price: 0,
    inventory: 0,
    description: "",
    image: "三体.jpg",
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let inputValue = e.target.value;
    let inputName = e.target.name;
    setInfo({ ...info, [inputName]: inputValue });
  };

  const handleCancel = () => {
    setInfo(tmpInfo);
  };

  const handleSave = () => {
    if (
      info.name &&
      info.author &&
      info.price &&
      info.isbn &&
      info.description
    ) {
      addBook(info).then(() => alert("Saved!"));
      setInfo(tmpInfo);
    } else {
      alert("Please fill in all the information!");
    }
  };

  return (
    <>
      <h1>AddBookView</h1>

      <h1>{info.name}</h1>
      <div className={"book-detail"}>
        <div className={"book-image"}>
          <Image alt="image" src={require("../assets/books/三体.jpg")} />
        </div>
        <div className="des-group">
          <Descriptions className="all-des">
            <Descriptions.Item label={"Title"} span={3}>
              <Input
                name={"name"}
                value={info.name}
                onChange={handleInputChange}
              />
            </Descriptions.Item>
            <Descriptions.Item label={"Author"} span={3}>
              <Input
                name={"author"}
                value={info.author}
                onChange={handleInputChange}
              />
            </Descriptions.Item>

            <Descriptions.Item label={"Price"} span={3}>
              <Input
                name={"price"}
                value={info.price}
                onChange={handleInputChange}
              />
            </Descriptions.Item>
            <Descriptions.Item label={"ISBN"} span={3}>
              <Input
                name={"isbn"}
                value={info.isbn}
                onChange={handleInputChange}
              />
            </Descriptions.Item>
            <Descriptions.Item label={"State"} span={3}>
              <Input
                name={"inventory"}
                value={info.inventory}
                onChange={handleInputChange}
              />
            </Descriptions.Item>
          </Descriptions>
        </div>
      </div>
      <br></br>
      <div className={"book-intro"}>
        <Descriptions className="int-des">
          <Descriptions.Item label={"Introduce"} span={3}>
            <Input
              name={"description"}
              value={info.description}
              onChange={handleInputChange}
            ></Input>
          </Descriptions.Item>
        </Descriptions>
      </div>

      <div
        style={{
          marginTop: "20px",
          display: "flex",
          justifyContent: "center",
        }}
      >
        <div style={{ marginRight: "20px" }}>
          <Button danger size={"large"} onClick={handleSave}>
            save
          </Button>
        </div>
        <div>
          <Button type="primary" danger size={"large"} onClick={handleCancel}>
            cancel
          </Button>
        </div>
      </div>
    </>
  );
}
