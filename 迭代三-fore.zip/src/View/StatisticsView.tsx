export function StatisticsView() {
  return (
    <div>
      <h1>Statistic</h1>
    </div>
  );
}
