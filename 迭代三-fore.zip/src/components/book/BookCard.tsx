import React from "react";
import { Link } from "react-router-dom";
import { Button, Card, Image, Radio } from "antd";
import "../../css/Book.css";
import { deleteBook } from "../../Service/BookService";

const { Meta } = Card;

interface BookCardProps {
  image: string;
  title: string;
  price: number;
  id: number;
  isDelete?: boolean;
  deleted?: boolean;
  setDeleted?: (deleted: boolean) => void;
}

export function BookCard({
  image,
  title,
  price,
  id,
  isDelete,
  deleted,
  setDeleted,
}: BookCardProps) {
  // const info = props;

  const handleDelete = () => {
    if (setDeleted) {
      deleteBook(id).then(() => setDeleted(true));
    }
  };
  return (
    <>
      <div
        style={{
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <Link to={`/home/books/${id}`}>
          <Card
            hoverable
            className="book"
            style={{
              borderStyle: "solid",
              borderWidth: "3px",
              borderColor: "rgba(0, 0, 0, 0.4)",
            }}
            cover={
              <Image
                className="book-img"
                alt="image"
                src={require(`../../assets/books/${image}`)}
              />
            }
          >
            <Meta title={title} description={"¥" + price} />
          </Card>
        </Link>
        {isDelete && (
          <Button
            style={{ marginLeft: "45px", marginTop: "10px" }}
            onClick={handleDelete}
          >
            Delete
          </Button>
        )}
      </div>
    </>
  );
}
